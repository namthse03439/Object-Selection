package tasks.jun25_labeling;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import ds.nebula.forbak.ForbakDocument;
import ds.nebula.util.FolderAccess;
import ds.nebula.visio.Visioner;
import ds.nebula.visio.images.CatImage;
import ds.nebula.visio.images.MaskImage;

public class task2_labeling_big_hat {

	public static void main(String[] args) 
	throws Exception
	{
		File f = FolderAccess
				.start()
				.getDesktopFile("data-watershed/mexicanhat.jpg");
		
		ForbakDocument d = step1_label_file(f);
		step2_label_image(f, d);		
	}

	private static void step2_label_image(File f, ForbakDocument d) 
	throws Exception
	{
		FolderAccess db = FolderAccess.start();
		
		MaskImage fig1 = Visioner.createMask(f, d.getAnchorPoints("F"));
		db.setFigureFile(db.getDesktopFile("figure1.png")).figure(fig1, Color.red);
		
		MaskImage fig2 = Visioner.createMask(f, d.getAnchorPoints("B"));
		db.setFigureFile(db.getDesktopFile("figure2.png")).figure(fig2, Color.blue);
		
		CatImage c = Visioner.label(fig1, fig2);
		BufferedImage img = Visioner.select(ImageIO.read(f), c, 0);
		db.setFigureFile(db.getDesktopFile("figure3.png")).figure(img);		
	}

	private static ForbakDocument step1_label_file(File f) 
	throws Exception
	{
		ForbakDocument d = ForbakDocument.startWithImage(f);
		d.addPixels(102, 153, 399, 156, "F");
		d.addPixels(234, 200, 343, 300, "F");
		d.addPixels(33, 23, 22, 308, "B");
		
		d.save( d.getFileForSaving() );
		FolderAccess.start().figure( d.getImageAndAnchors() );		
		
		return d;
	}

}
