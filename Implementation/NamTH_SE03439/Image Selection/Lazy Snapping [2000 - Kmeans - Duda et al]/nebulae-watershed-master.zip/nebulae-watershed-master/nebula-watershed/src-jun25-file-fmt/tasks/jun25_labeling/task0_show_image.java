package tasks.jun25_labeling;

import java.io.File;

import ds.nebula.util.FigureFrame;
import ds.nebula.util.FolderAccess;

public class task0_show_image {

	public static void main(String[] args) 
		throws Exception
		{
			File f = FolderAccess
					.start()
					.getDesktopFile("data-watershed/flowers.jpg");
			
			FigureFrame.start(f).show();
	}

}
