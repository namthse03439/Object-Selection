package ds.nebula.spkm;

public class kmeansCenter 
{
	private int cnt = 0;
	private double[] acc = null;
	
	public void add(double[] member) 
	{
		if(acc == null) acc = new double[member.length];
		for(int n=member.length, k=0; k<n; k++) acc[k] += member[k];	
		
		cnt++;
	}

	public void average() 
	{
		if(cnt == 0) return;
		for(int n=acc.length, k=0; k<n; k++) acc[k] /= cnt;			
		//System.out.printf("center %d %f %f %f\n", cnt, acc[0], acc[1], acc[2]);
	}

	public double[] getVector()
	{
		return acc;
	}

	public int getCount() 
	{
		return cnt;
	}

}
