package ds.nebula.visio.images;

public class DoubleImage extends VectorImage<Double>
{

	public DoubleImage(int width, int height) 
	{
		// TODO Auto-generated constructor stub
	}

}
