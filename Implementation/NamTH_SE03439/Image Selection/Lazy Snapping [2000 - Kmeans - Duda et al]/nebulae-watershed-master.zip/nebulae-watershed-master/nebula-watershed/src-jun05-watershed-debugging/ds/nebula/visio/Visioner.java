package ds.nebula.visio;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;

import ds.nebula.util.FileDataAccess;
import ds.nebula.util.HtmlWriter;
import ds.nebula.visio.func.VisionerAction;
import ds.nebula.visio.images.CatImage;
import ds.nebula.visio.images.MaskImage;


public class Visioner 
{
	public static final boolean EXEC_THIS_BLOCK = false;

	public static void start() 
	{
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
	}

	public static Mat gaussianBlur(Mat img, int cx, int cy) 
	{
		Mat res = new Mat(img.rows(), img.cols(), img.type());
		Imgproc.GaussianBlur(img, res, new Size(cx, cy), 0);
		return res;
	}

	public static Mat gaussianBlur(File s, File t1, String t2, int cx, int cy) 
	{
		Mat img = Highgui.imread(s.getAbsolutePath(), Highgui.CV_LOAD_IMAGE_ANYCOLOR);
		
		Mat res = new Mat(img.rows(), img.cols(), img.type());
		Imgproc.GaussianBlur(img, res, new Size(cx, cy), 0);
		
		t1 = new File(t1.getAbsolutePath() + "/" + t2);
		Highgui.imwrite(t1.getAbsolutePath(), res);
		
		return res;
	}
	public static Mat gaussianBlur(File s, File t1, int cx, int cy) 
	{
		Mat img = Highgui.imread(s.getAbsolutePath(), Highgui.CV_LOAD_IMAGE_ANYCOLOR);
		
		Mat res = new Mat(img.rows(), img.cols(), img.type());
		Imgproc.GaussianBlur(img, res, new Size(cx, cy), 0);
		
		Highgui.imwrite(t1.getAbsolutePath(), res);
		
		return res;
	}
	public static Mat imread(File f) 
	{
		return Highgui.imread(f.getAbsolutePath(), Highgui.CV_LOAD_IMAGE_ANYCOLOR);
	}

	public static List<File> readFiles(File f, String ends) 
	{
		List<File> res = new ArrayList<File>();
		
		File[] files = f.listFiles();
		if(files != null) 
			for(File fk: files)
				if(fk.getName().endsWith(ends)) res.add(fk);
		
		return res;
	}

	
	public static File figure(String fname, List<File> files, VisionerAction lf) throws Exception
	{
		File f = FileDataAccess.getDesktopFile("data-visioner/" + fname);
		
		File outf = new File(f.getParentFile().getAbsolutePath() + "/images");
		outf.mkdirs();
		
		HtmlWriter out = new HtmlWriter(f);
		
		out.printStyles(
				"td { padding: 5px; }",
				".w64 { width: 64px; }",
				".w128 { width: 128px; }"
				); 
		
	
		
		out.table();
		for(File fk: files) lf.invokeVisionerAction(fk, out, outf);			
		out.tableEnd();
		out.close();
		
		try { Desktop.getDesktop().open(f);	}
		catch(Exception xp) { error(xp); }		
		
		return f;
	}

	public static void figure(String fname, Mat m) 
	{
		File f = FileDataAccess.getDesktopFile("data-visioner/" + fname);
		f.getParentFile().mkdirs();
		
		Highgui.imwrite(f.getAbsolutePath(), m); 
		
		try { Desktop.getDesktop().open(f);	}
		catch(Exception xp) { error(xp); }		
	}

	public static void copyImage(File s, File t1, String t2) 
	{
		t1 = new File(t1.getAbsolutePath() + "/" + t2);
		
		try 
		{
			BufferedImage img = ImageIO.read(s);
			ImageIO.write(img, "png", t1);
		}
		
		catch(Exception xp) { error(xp); }
	}

	public static void error(Exception xp) 
	{
		
	}

	public static Mat erode(Mat source) 
	{
		Mat destination = new Mat(source.rows(), source.cols(), source.type());

//		destination = source;

		int erosion_size = 5;

		Mat element = Imgproc.getStructuringElement(Imgproc.MORPH_RECT,
				new Size(2 * erosion_size + 1, 2 * erosion_size + 1));
		
		Imgproc.erode(source, destination, element);
		
		return destination;
	}

	public static Mat dilate(Mat source) 
	{
		int dilation_size = 5;
		
		Mat destination = new Mat(source.rows(), source.cols(), source.type());
		
		Mat element1 = Imgproc.getStructuringElement(Imgproc.MORPH_RECT,
				new Size(2 * dilation_size + 1, 2 * dilation_size + 1));
		
		Imgproc.dilate(source, destination, element1);
		
		return destination;
	}

	public static void show(File f) 
	{
		try { Desktop.getDesktop().open(f);	}
		catch(Exception xp) { error(xp); }				
	}

	public static MaskImage createMask(BufferedImage img, List<Point> points) 
	{
		int Rx = img.getWidth(), Ry = img.getHeight();
		MaskImage res = MaskImage.start(Rx, Ry);
		
		List<Color> colors = colorsFromPoints(points, img);
		
		for(int y=0; y<Ry; y++)
		for(int x=0; x<Rx; x++)
		{
			Color cxy = new Color(img.getRGB(x, y));
			
			double dmin = Double.MAX_VALUE;
			for(Color ck: colors)
			{
				double dk = colorDiff(cxy, ck);
				if(dk < dmin) dmin = dk;
			}
			
			res.set(x, y, Math.exp(-dmin));
		}
		
		return res;
	}

	private static double colorDiff(Color a, Color b) 
	{
		int R = a.getRed() - b.getRed();
		int G = a.getGreen() - b.getGreen();
		int B = a.getBlue() - b.getBlue();
		int A = a.getAlpha() - b.getAlpha();
		
		return Math.sqrt(R*R + G*G + B*B + A*A)/2;
	}

	private static List<Color> colorsFromPoints(List<Point> points, BufferedImage img) 
	{
		List<Color> res = new ArrayList<Color>();
		for(Point pk: points)
		{
			int rk = img.getRGB(pk.x, pk.y);
			res.add(new Color(rk));
		}
		return res;
	}

	public static MaskImage createMask(File f, List<Point> p1) 
	throws Exception
	{
		return createMask(ImageIO.read(f), p1);
	}

	public static CatImage label(MaskImage fig1, MaskImage fig2) 
	{
		int rx = fig1.getRx(), ry = fig1.getRy();
		CatImage res = CatImage.start(rx, ry);
		
		for(int y=0; y<ry; y++)
		for(int x=0; x<rx; x++)
		{
			double f1 = fig1.get(x, y);
			double f2 = fig2.get(x, y);
			res.set(x, y, f1>f2 ? 0 : 1); 
		}
		
		return res;
	}

	public static BufferedImage select(BufferedImage img, CatImage c, int c0) 
	{
		int rx = img.getWidth(), ry = img.getHeight(), rd = img.getType();
		BufferedImage res = new BufferedImage(rx, ry, rd);
		
		
		for(int y=0; y<ry; y++)
		for(int x=0; x<rx; x++)
		{
			if(c.get(x, y)==c0)
			res.setRGB(x, y, img.getRGB(x, y)); 
		}
				
		return res;
	}


}
