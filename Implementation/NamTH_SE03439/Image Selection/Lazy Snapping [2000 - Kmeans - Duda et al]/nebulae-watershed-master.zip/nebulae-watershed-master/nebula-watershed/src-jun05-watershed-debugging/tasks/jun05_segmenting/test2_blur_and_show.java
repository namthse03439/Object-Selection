package tasks.jun05_segmenting;

import java.io.File;

import org.opencv.core.Mat;

import ds.nebula.util.FileDataAccess;
import ds.nebula.visio.Visioner;

public class test2_blur_and_show 
{

	public static void main(String[] args) 
	{
		Visioner.start();
		
		File f = FileDataAccess.getDesktopFile("data-watershed/blue-fish.jpg");
		System.out.println(f.getAbsolutePath());
		Mat m = Visioner.imread(f);
		
		m = Visioner.gaussianBlur(m, 45, 45);
		Visioner.figure("test1.jpg", m);
	}
}
