package ds.nebula.visio.func;

import java.awt.Color;

public class LinearColorMapper implements ColorMapper 
{
	private int baseR;
	private int baseG;
	private int baseB;
	private int baseA;

	public LinearColorMapper(Color b) 
	{
		baseR = b.getRed();
		baseG = b.getGreen();
		baseB = b.getBlue();
		baseA = b.getAlpha();
	}

	@Override
	public Color invokeColorMapper(double v) 
	{
		int r = (int)(v * baseR);
		int g = (int)(v * baseG);
		int b = (int)(v * baseB);
		
		return new Color(r, g, b);
	}

}
