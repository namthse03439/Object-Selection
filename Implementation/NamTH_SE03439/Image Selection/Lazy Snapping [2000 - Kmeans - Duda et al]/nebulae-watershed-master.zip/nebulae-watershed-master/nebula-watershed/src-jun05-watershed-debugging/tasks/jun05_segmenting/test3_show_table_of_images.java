package tasks.jun05_segmenting;

import java.io.File;
import java.util.List;

import ds.nebula.util.FileDataAccess;
import ds.nebula.visio.Visioner;

public class test3_show_table_of_images {

	public static void main(String[] args) throws Exception
	{
		Visioner.start();
		
		File f = FileDataAccess.getDesktopFile("data-watershed");
		
		List<File> files = Visioner.readFiles(f, ".jpg");
		Visioner.figure("test1.html", files,
				(fk, out, outf) -> 
		{ 
			System.out.println(fk);
			
			out.tr();
			Visioner.copyImage(fk, outf, fk.getName());
			
			String g1 = fk.getName() + "-g23x23.png";
			try { Visioner.gaussianBlur(fk, outf, g1, 23, 23); } catch(Exception xp) {}
			
			String g2 = fk.getName() + "-g45x45.png";
			try { Visioner.gaussianBlur(fk, outf, g2, 45, 45); } catch(Exception xp) {}
			
			out.printFields(fk.getName(),
					out.imageText(outf.getName() + "/" + fk.getName(), "w128"),
					out.imageText(outf.getName() + "/" + g1, "w128"),
					out.imageText(outf.getName() + "/" + g2, "w128"),
					"watershed k");
			out.trEnd();
		});
		
		return;
	}

}
