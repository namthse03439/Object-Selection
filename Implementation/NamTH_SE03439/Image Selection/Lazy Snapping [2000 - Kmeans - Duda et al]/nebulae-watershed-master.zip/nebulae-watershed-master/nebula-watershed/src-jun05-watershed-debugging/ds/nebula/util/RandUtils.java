package ds.nebula.util;

import java.awt.Color;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

public class RandUtils 
{
	protected Random coin = new Random(197);
	protected Map<Integer, Color> colors = new TreeMap<Integer, Color>();

	public Color nextColor(int i) 
	{
		Color c = colors.get(i);
		if(c != null) return c;
		
		colors.put(i, nextColor());
		
		return colors.get(i);
	}

	public Color nextColor() 
	{
		int r = coin.nextInt(256);
		int g = coin.nextInt(256);
		int b = coin.nextInt(256);
		return new Color(r, g, b);
	}

}
