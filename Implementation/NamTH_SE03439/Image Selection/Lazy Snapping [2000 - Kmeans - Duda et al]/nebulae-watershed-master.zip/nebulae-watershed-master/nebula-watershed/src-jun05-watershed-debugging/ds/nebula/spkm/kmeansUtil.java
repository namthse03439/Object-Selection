package ds.nebula.spkm;

import ds.nebula.visio.images.CatImage;
import ds.nebula.visio.images.VectorImage;

public class kmeansUtil {

	public kmeansCenter[] kmeansAveraging(
			VectorImage<double[]> img, CatImage L, int kpar)
	{
		int Rx = img.getRx(), Ry = img.getRy();
		
		kmeansCenter[] res = new kmeansCenter[kpar];
		for(int k=0; k<kpar; k++) res[k] = new kmeansCenter();
		//System.out.println("Rx=" + Rx);
		//System.out.println("Ry=" + Ry);
		//System.out.println("kpar=" + kpar);
		
		for(int y=0; y<Ry; y++)
		for(int x=0; x<Rx; x++) 
		{
			double[] ck = img.get(x, y);
			int lk = L.get(x, y);
			res[lk].add(ck);
			//System.out.printf("lk=%d c=(%f, %f, %f) \n", lk, ck[0], ck[1], ck[2]);
		}						

		for(int k=0; k<kpar; k++) res[k].average(); 
		return res;
	}

	public CatImage kmeansLabeling(VectorImage<double[]> img, kmeansCenter[] C, CatImage L)
	{
		int Rx = img.getRx(), Ry = img.getRy(), kpar = C.length;
		
		for(int y=0; y<Ry; y++)
		for(int x=0; x<Rx; x++) 
		{
			double[] vj = img.get(x, y);
			
			int lmin = 0;
			double dmin = Double.MAX_VALUE;
			
			for(int k=0; k<kpar; k++)
			if(C[k].getCount() > 0)
			{
				double dk = kmeanDist(vj, C[k].getVector());
				if(dmin > dk) { dmin = dk; lmin = k; }
			}
			
			L.set(x, y, lmin);
		}						

		return L;
	}

	public double kmeanDist(double[] a, double[] b) 
	{
		int n = Math.max(a.length, b.length);
		
		double s = 0;
		for(int k=0; k<n; k++)
		{
			double sk = a[k] - b[k];
			s += sk * sk;
		}

		return s / n;
	}
}
