package ds.nebula.visio.images;

import java.awt.Color;

public interface VectorImageAction {

	double[] invokeVectorAction(Color ck, int x, int y);

}
