package ds.nebula.visio.func;

import java.awt.Color;

public interface ColorMapper {

	Color invokeColorMapper(double dxy);

}
