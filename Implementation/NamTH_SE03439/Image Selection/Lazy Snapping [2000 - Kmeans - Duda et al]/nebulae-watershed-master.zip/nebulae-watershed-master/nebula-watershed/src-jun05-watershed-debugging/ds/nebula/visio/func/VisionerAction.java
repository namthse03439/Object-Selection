package ds.nebula.visio.func;

import java.io.File;

import ds.nebula.util.HtmlWriter;

public interface VisionerAction {

	public void invokeVisionerAction(File fk, HtmlWriter out, File outf);

}
