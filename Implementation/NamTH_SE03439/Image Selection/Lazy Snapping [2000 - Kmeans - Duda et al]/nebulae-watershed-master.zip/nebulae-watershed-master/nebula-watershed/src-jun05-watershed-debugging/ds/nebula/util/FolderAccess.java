package ds.nebula.util;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import ds.nebula.visio.func.LinearColorMapper;
import ds.nebula.visio.images.CatImage;
import ds.nebula.visio.images.MaskImage;

public class FolderAccess
{
	private File figureFile;
	private boolean figureShow;
	
	public static FolderAccess start()
	{
		return new FolderAccess();
	}


	public File getDataFile(String string) 
	{
		return new File(System.getProperty("user.home") + "/" + string);
	}

	public File getDesktopFile(String string) 
	{
		return new File(System.getProperty("user.home") + "/Desktop/" + string);
	}

	public void figure(BufferedImage img) 
	throws Exception
	{
		File f = (figureFile==null 
				? this.getDataFile("data-figure101/" + System.nanoTime() + ".png")
						: figureFile);
		
		f.getParentFile().mkdirs();
		ImageIO.write(img, "png", f);
		
		if(figureShow)Desktop.getDesktop().open(f);
	}
	
	public FolderAccess setFigureFile(File f)
	{
		figureFile = f;
		return this;
	}

	public void figure(MaskImage fig1, Color red) 
	throws Exception
	{
		 BufferedImage img = fig1.getBufferedImage( new LinearColorMapper(red) );
		 figure(img);		
	}

	public void figure(CatImage c) 
	throws Exception
	{
		BufferedImage img = c.toPng(new RandUtils());
		figure(img);
	}


}
