package ds.nebula.visio.images;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class VectorImage<T> 
{
	protected Class<T> dataClass;
	protected int X0;
	protected int Y0;
	private int Rx;
	private int Ry;
	private T[][] pixels;
	
	public static VectorImage<Double> startDouble(int Rx, int Ry)
	{
		VectorImage<Double> res = new VectorImage<Double>();
		
		res.dataClass = Double.class;
		res.pixels = new Double[Ry][Rx];
		
		res.Rx = Rx;
		res.Ry = Ry;
		
		return res;
	}
	
	public static VectorImage<double[]> from(BufferedImage img)
	{
		VectorImage<double[]> res = new VectorImage<double[]>();
		
		res.dataClass = double[].class;
		int Rx = res.Rx = img.getWidth();
		int Ry = res.Ry = img.getHeight();
		
		res.X0 = Rx/2;
		res.Y0 = Ry/2;
		
		res.pixels = new double[Ry][Rx][];
		 
		for(int x=0; x<Rx; x++)
		for(int y=0; y<Ry; y++)
		{
			Color ck = new Color( img.getRGB(x, y) );
			res.pixels[y][x] = res.vectorFromColor(ck, x, y);
		}		
		
		return res;
	}
	
	public static VectorImage<double[]> from(BufferedImage img, VectorImageAction lf)
	{
		VectorImage<double[]> res = new VectorImage<double[]>();
		
		res.dataClass = double[].class;
		int Rx = res.Rx = img.getWidth();
		int Ry = res.Ry = img.getHeight();
		
		res.X0 = Rx/2;
		res.Y0 = Ry/2;
		
		res.pixels = new double[Ry][Rx][];
		 
		for(int x=0; x<Rx; x++)
		for(int y=0; y<Ry; y++)
		{
			Color ck = new Color( img.getRGB(x, y) );
			res.pixels[y][x] = lf.invokeVectorAction(ck, x, y);
		}		
		
		return res;
	}	

	public double[] vectorFromColor(Color ck, int x, int y)
	{
		return new double[] { ck.getRed(), ck.getGreen(), ck.getBlue() };
	}

	public int getRx() 
	{
		return Rx;
	}

	public int getRy() 
	{
		return Ry;
	}

	public T get(int x, int y) 
	{
		return pixels[y][x];
	}
}
