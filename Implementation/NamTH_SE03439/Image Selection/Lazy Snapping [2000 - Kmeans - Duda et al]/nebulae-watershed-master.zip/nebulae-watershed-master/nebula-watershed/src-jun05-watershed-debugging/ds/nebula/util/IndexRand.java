package ds.nebula.util;

import java.util.Random;

public class IndexRand 
{
	protected Random coin = new Random(197);
	
	protected int BASE = 0;
	protected int RANGE = Integer.MAX_VALUE;
	
	public IndexRand()
	{
		
	}
	
	public IndexRand(int r)
	{
		RANGE = r;
	}

	public int nextIndex()
	{
		return BASE + coin.nextInt(RANGE);
	}

}
