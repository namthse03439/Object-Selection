package ds.nebula.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class HtmlWriter {

	private File target;
	public Field[] fields;
	private PrintWriter out;

	public HtmlWriter(File f) throws Exception
	{
		f.getParentFile().mkdirs();
		target = f;

		FileOutputStream t = new FileOutputStream(f);
		t.write(new byte[] { (byte) 239, (byte) 187, (byte) 191 });
		out = new PrintWriter(new OutputStreamWriter(t, "UTF-8"), true);
		
		//out = new PrintWriter(f, "UTF-8");
	}
	
	public HtmlWriter(PrintWriter t) 
	{
		out = t;
	}

	public HtmlWriter(Writer t) 
	{
		out = new PrintWriter(t);
	}

	public PrintWriter getWriter()
	{
		return out;
	}

	public File close()
	{
		out.close();
		return target;
	}

	public void println()
	{
		out.println();
	}
	
	public void println(String string)
	{
		out.println(string);
	}
	
	public void printFields(Object... fields)
	{
		out.print("<tr>");
		for(Object ak: fields) out.print("<td>"+ak+"</td>"); 
		out.println("</tr>");
	}
	
	public void printHeaders(Field... fields) 
	{
		out.print("<tr>");
		for(Field ak: fields) out.print("<td>"+ak.getName()+"</td>"); 
		out.println("</tr>");		
	}
	
	public void printHeaders(Set<String> fields) 
	{
		out.print("<tr>");
		for(String ak: fields) out.print("<td>"+ak+"</td>"); 
		out.println("</tr>");		
	}
	
	public void printFieldsAttr(String attr, Object... fields)
	{
		out.print("<tr>");
		for(Object ak: fields) out.print("<td "+attr+">"+ak+"</td>"); 
		out.println("</tr>");
	}
	
	public void printObjectAsRow(Object obj) throws Exception 
	{
		if(fields == null) 
		{
			fields = getPublicFields(obj);
			out.print("<tr>");
			for(Field fk: fields) out.print("<td>"+fk.getName()+"</td>"); 
			out.println("</tr>");		
		}
		
		out.print("<tr>");
		for(Field fk: fields) out.print("<td>"+fk.get(obj)+"</td>"); 
		out.println("</tr>");		
		
	}
	
	@SuppressWarnings("unchecked")
	public void printMapAsRow(Object s, List<String> fields)  
	{
		Map<String, Object> obj = (Map<String, Object>)s;
		
		out.print("<tr>");
		for(String fk: fields) out.print("<td>"+obj.get(fk)+"</td>"); 
		out.println("</tr>");				
	}
	
	@SuppressWarnings("unchecked")
	public void printMapAsRow(Object s, Set<String> fields)  
	{
		Map<String, Object> obj = (Map<String, Object>)s;
		
		out.print("<tr>");
		for(String fk: fields) out.print("<td>"+obj.get(fk)+"</td>"); 
		out.println("</tr>");				
	}
	

	public<T> void printListAsRow(List<T> names) 
	{
		out.print("<tr>");
		for(T nk: names) out.print("<td>"+nk+"</td>"); 
		out.println("</tr>");						
	}
	
	public void printStrings(String... fields)
	{
		out.print("<tr>");
		for(Object ak: fields) out.print("<td>"+ak+"</td>"); 
		out.println("</tr>");
	}	

	
	public void printHeaders(List<String> fields)
	{
		out.print("<tr>");
		for(String ak: fields) out.print("<th>"+ak+"</th>"); 
		out.println("</tr>");
	}	
		
	public void printHeaders(String... fields)
	{
		out.print("<tr>");
		for(Object ak: fields) out.print("<th>"+ak+"</th>"); 
		out.println("</tr>");
	}	
	
	public void table() {
		out.println("<table border=1>");		
	}
	
	public void table(String cl) {
		out.println("<table class="+cl+">");		
	}
	
	public void table0() {
		out.println("<table>");				
	}	
	
	public void tableEnd() {
		out.println("</table>");		
	}


	public void printStyles(String... args) 
	{
		out.println("<style>");		
		for(String ak: args) out.println(ak);
		out.println("</style>");		
	}

	public void link(String uk) 
	{
		out.println("<a href='"+uk+"'>"+uk+"</a>");
	}
	
	public void link(String uk, String tk) 
	{
		out.println("<a href='"+uk+"'>"+tk+"</a>");
	}

	public void flush() 
	{
		out.flush();
	}

	public void h1(String text) 
	{
		out.println("<h1>"+text+"</h1>");
	}
	
	public void h1(String attr, String text)
	{
		out.println("<h1 "+attr+">"+text+"</h1>");		
	}

	public void h2(String text) 
	{
		out.println("<h2>"+text+"</h2>");
	}

	public void h3(String text) 
	{
		out.println("<h3>"+text+"</h3>");
	}
	
	public void hr() 
	{
		out.println("<hr>");
	}

	public void tr() 
	{
		out.println("<tr>");		
	}
	
	public void trEnd() 
	{
		out.println("</tr>");		
	}

	public void td() 
	{
		out.println("<td>");		
	}
	
	public void tdEnd() 
	{
		out.println("</td>");		
	}

	public void td(Object s) 
	{
		out.println("<td>"+s+"</td>");		
	}

	public void td2(String cl, String inner) 
	{
		out.println("<td class="+cl+">"+inner+"</td>");		
	}

	public void anchor(String text, String link) 
	{
		out.println("<a href='"+link+"'>"+text+"</a>");
		
	}

	public String spanText(String text, String cl) 
	{
		return "<span class='"+cl+"'>"+text+"</span>";
	}
	
	public String anchorText(String text, String link) 
	{
		return "<a href='"+link+"'>"+text+"</a>";
	}
	
	public String anchorTextTar(String text, String link) 
	{
		return "<a target=_blank href='"+link+"'>"+text+"</a>";
	}
	
	public String imageText(String sk, String cl) 
	{
		return "<img src='"+sk+"' class='"+cl+"'>";
	}
	
	public void middot() 
	{
		out.println("&middot;");
	}

	public void middot2() 
	{
		out.println("&nbsp;&middot;&nbsp;");
	}

	public void div(String s) 
	{
		out.println("<div>"+s+"</div>");		
	}

	public void br() 
	{
		out.print("<br>");
	}

	public void p(String string) 
	{
		out.println("<p>"+string+"</p>");		
	}




	public static Field[] getPublicFields(Object ik) 
	{
		List<Field> res = new ArrayList<Field>();
		
		for(Field fk: ik.getClass().getDeclaredFields())
			if( Modifier.isPublic(fk.getModifiers()) ) res.add(fk);
		
		return res.toArray(new Field[] {});
	}

	@SuppressWarnings("unchecked")
	public List<String> getFieldsFromMap(Object s) 
	{
		Map<String, Object> obj = (Map<String, Object>)s;
		List<String> res = new ArrayList<String>();
		res.addAll(obj.keySet());
		return res;
	}
	

}
