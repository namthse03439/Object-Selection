package tasks.jun05_categorical_images;

import java.io.File;
import java.util.List;

import ds.nebula.util.FileDataAccess;
import ds.nebula.visio.Visioner;
import ds.nebula.visio.images.CatImage;

public class test2_in_table 
{

	public static void main(String[] args) throws Exception
	{
		Visioner.start();
		
		File f = FileDataAccess.getDesktopFile("data-watershed");
		
		List<File> files = Visioner.readFiles(f, ".jpg");
		
		Visioner.figure("test1.html", files,
				(fk, out, outf) -> 
		{ 
			System.out.println(fk);
			
			out.tr();
			Visioner.copyImage(fk, outf, fk.getName());
			
			String rel0 = generateGaussian(fk, outf);
			
			String rel1 = generateKmeans(fk, outf);
			
			File f0 = new File(outf.getParentFile() + "/" + rel0);
			String rel2 = generateGaussianKmeans(f0, outf);
			
			
			out.printFields(fk.getName(),
					out.imageText(outf.getName() + "/" + fk.getName(), "-w128"),
					out.imageText(rel1, "-w128"),
					out.imageText(rel0, "-w128"),
					out.imageText(rel2, "-w128"),
					"&nbsp;");
			out.trEnd();
		});
		
		return;
	}

	private static String generateGaussianKmeans(File fk, File outf) 
	{
		String g1 = fk.getName() + "-kmeans.png";
		File f1 = new File(outf.getAbsolutePath() + "/" + g1);
		try { CatImage.labelWithSpatialKmeans(fk, 150, 10).toPng(f1); } 
		catch(Exception xp) { xp.printStackTrace(); }
		
		return outf.getName() + "/" + g1;
	}

	private static String generateKmeans(File fk, File outf) 
	{
		String g2 = fk.getName() + "-kmeans.png";
		File f2 = new File(outf.getAbsolutePath() + "/" + g2);
		try { CatImage.labelWithSpatialKmeans(fk, 150, 10).toPng(f2); } 
		catch(Exception xp) { xp.printStackTrace(); }
		
		return outf.getName() + "/" + g2;
	}

	private static String generateGaussian(File fk, File outf) 
	{
		 String g0 = fk.getName() + "-gb.png";
			File f0 = new File(outf.getAbsolutePath() + "/" + g0);
			try { Visioner.gaussianBlur(fk, f0, 21, 21); }
			catch(Exception xp) { xp.printStackTrace(); }
			
		return outf.getName() + "/" + g0;
	}

}
