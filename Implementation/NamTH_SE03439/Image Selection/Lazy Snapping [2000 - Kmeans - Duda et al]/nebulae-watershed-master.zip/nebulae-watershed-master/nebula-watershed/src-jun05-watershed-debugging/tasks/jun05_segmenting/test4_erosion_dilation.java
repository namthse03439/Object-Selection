package tasks.jun05_segmenting;

import java.io.File;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;

import ds.nebula.util.FileDataAccess;
import ds.nebula.visio.Visioner;

public class test4_erosion_dilation {

	// see http://www.tutorialspoint.com/java_dip/eroding_dilating.htm
	public static void main(String[] args) throws Exception 
	{
		Visioner.start();
		
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		
		File f = FileDataAccess.getDesktopFile("data-watershed/blue-fish.jpg");
		System.out.println(f.getAbsolutePath());
		
		Mat source = Visioner.imread(f);
		Mat destination = Visioner.erode(source);
		Visioner.figure("test1-erosion.png", destination);
		
		destination = Visioner.dilate(source);
		Visioner.figure("test2-dilation.png", destination);
	}
}
