package ds.nebula.forbak;

public class ForbakPoint {

	public int x;
	public int y;
	public String color;

}
