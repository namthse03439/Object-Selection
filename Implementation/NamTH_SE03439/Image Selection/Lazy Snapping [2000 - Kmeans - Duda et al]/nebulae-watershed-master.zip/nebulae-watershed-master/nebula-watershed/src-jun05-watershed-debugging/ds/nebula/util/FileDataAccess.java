package ds.nebula.util;

import java.io.File;

public class FileDataAccess {

	public static File getDataFile(String string) 
	{
		return new File(System.getProperty("user.home") + "/" + string);
	}

	public static File getDesktopFile(String string) 
	{
		return new File(System.getProperty("user.home") + "/Desktop/" + string);
	}
}
