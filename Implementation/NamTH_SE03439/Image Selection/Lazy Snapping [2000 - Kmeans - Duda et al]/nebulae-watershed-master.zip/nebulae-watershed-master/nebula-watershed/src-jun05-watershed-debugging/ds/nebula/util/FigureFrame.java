package ds.nebula.util;

import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class FigureFrame 
{
	private File dataFile;
	private JFrame mainFrame;
	private JLabel mainView;

	public static FigureFrame start(File f) 
	throws Exception
	{
		return start(ImageIO.read(f), f);
	}
	
	public static FigureFrame start(BufferedImage img) 
	{
		return start(img, null);
	}
	
	public static FigureFrame start(BufferedImage img, File imgf) 
	{
		FigureFrame f = new FigureFrame();
		
		f.dataFile = imgf;
		
		f.mainView = new JLabel();
		f.mainView.setIcon(new ImageIcon(img));
		
		f.mainFrame = new JFrame();
		if(f.dataFile != null) f.mainFrame.setTitle(f.dataFile.getAbsolutePath());
		f.mainFrame.setLayout( new BorderLayout() );
		
		String top = "width: " + img.getWidth() + " height: " + img.getHeight();
		f.mainFrame.add(new JLabel(top), BorderLayout.PAGE_START);
//		f.mainFrame.add(new JLabel("bottom"), BorderLayout.PAGE_END);
//		f.mainFrame.add(new JLabel("left"), BorderLayout.WEST);
//		f.mainFrame.add(new JLabel("right"), BorderLayout.EAST);
		
		f.mainFrame.add(f.mainView, BorderLayout.CENTER);
		f.mainFrame.pack();
		
		return f;
	}

	public void show() 
	{
		mainFrame.pack();
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setVisible(true);
	}


}
