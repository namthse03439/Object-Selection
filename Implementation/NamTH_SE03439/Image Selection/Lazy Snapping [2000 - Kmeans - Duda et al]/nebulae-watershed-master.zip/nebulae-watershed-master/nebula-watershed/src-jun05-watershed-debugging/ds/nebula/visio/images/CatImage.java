package ds.nebula.visio.images;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.PrintWriter;

import javax.imageio.ImageIO;

import ds.nebula.spkm.kmeansCenter;
import ds.nebula.spkm.kmeansUtil;
import ds.nebula.util.IndexRand;
import ds.nebula.util.RandUtils;

public class CatImage 
{
	private int Rx;
	private int Ry;
	private int[][] dataYX;
	

	public int get(int x, int y) 
	{
		return dataYX[y][x];
	}

	public void set(int x, int y, int lmin) 
	{
		dataYX[y][x] = lmin;		
	}



	public void toText(File f) throws Exception
	{
		f.getParentFile().mkdirs();
		PrintWriter out = new PrintWriter(f);
		toText(out);
		out.close();
	}
	
	public void toText(PrintWriter out) 
	{
		for(int y=0; y<Ry; y++)
		{
			for(int x=0; x<Rx; x++) out.print(this.dataYX[y][x] + " ");
			out.println();
		}						
	}

	public void toPng(File f) throws Exception
	{
		BufferedImage img = toPng(new RandUtils());
		System.out.println(f.getAbsolutePath());
		ImageIO.write(img, "png", f);
	}

	public BufferedImage toPng(RandUtils r) 
	{
		BufferedImage res = new BufferedImage(Rx, Ry, BufferedImage.TYPE_4BYTE_ABGR);
		
		for(int y=0; y<Ry; y++)
		for(int x=0; x<Rx; x++) 
		{
			Color ck = r.nextColor(dataYX[y][x]);
			res.setRGB(x, y, ck.getRGB());
		}						
		
		return res;
	}
	
	public static CatImage rand(int cx, int cy, IndexRand r)
	{
		CatImage res = new CatImage();
		int Rx = res.Rx = cx;
		int Ry = res.Ry = cy;
		res.dataYX = new int[Ry][Rx];
		
		for(int x=0; x<Rx; x++)
		for(int y=0; y<Ry; y++)
		{
			res.dataYX[y][x] = r.nextIndex();
		}
		
		return res;
	}		
	
	public static CatImage label4096(File f) throws Exception
	{
		BufferedImage img = ImageIO.read(f);
		return label4096(img);
	}
	
	public static CatImage label4096(BufferedImage img) 
	{
		CatImage res = new CatImage();
		int Rx = res.Rx = img.getWidth();
		int Ry = res.Ry = img.getHeight();
		res.dataYX = new int[Ry][Rx];
		
		for(int x=0; x<Rx; x++)
		for(int y=0; y<Ry; y++)
		{
			Color ck = new Color( img.getRGB(x, y) );
			int r = ck.getRed() / 16;
			int g = ck.getGreen() / 16;
			int b = ck.getBlue() / 16;
			
			res.dataYX[y][x] = r + g*16 + b*256;
		}
		
		return res;
	}	

	public static CatImage labelWithKmeans(File f, int kpar, int max) throws Exception
	{
		BufferedImage img = ImageIO.read(f);
		VectorImage<double[]> X = VectorImage.from(img);		
		return labelWithKmeans(X, kpar, max);
	}

	public static CatImage labelWithSpatialKmeans(File f, int kpar, int max) throws Exception
	{
		BufferedImage img = ImageIO.read(f);
		VectorImage<double[]> X = VectorImage.from(img, 
				(ck, x, y) -> new double[] { 
						ck.getRed(), ck.getGreen(), ck.getBlue(), x, y });		
		
		return labelWithKmeans(X, kpar, max);
	}
	
	
	private static CatImage labelWithKmeans(VectorImage<double[]> img, int kpar, int maxiter) 
	{
		CatImage L = CatImage.rand(img.getRx(), img.getRy(), new IndexRand(kpar));
		
		kmeansUtil eng = new kmeansUtil();
		for(int t=0; t<maxiter; t++)
		{
			System.out.println("times=" + t);
			kmeansCenter[] C = eng.kmeansAveraging(img, L, kpar);
			L = eng.kmeansLabeling(img, C, L);
		}

		return L;
	}

	public static CatImage start(int Rx, int Ry) 
	{
		CatImage res = new CatImage();
		res.Rx = Rx;
		res.Ry = Ry;
		res.dataYX = new int[Ry][Rx];
		
		return res;
	}

}
