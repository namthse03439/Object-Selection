package tasks.jun05_categorical_images;

import java.io.File;

import ds.nebula.util.FileDataAccess;
import ds.nebula.visio.Visioner;
import ds.nebula.visio.images.CatImage;

public class test1_generating_saving {

	public static void main(String[] args) throws Exception
	{
		Visioner.start();
		
		File f = FileDataAccess.getDesktopFile("data-watershed/blue-fish.jpg");
		Visioner.show(f);
		
		CatImage img = null;
		
		if(Visioner.EXEC_THIS_BLOCK) 
		{
			img = CatImage.label4096(f);
		}
		
		if(Visioner.EXEC_THIS_BLOCK) {
			img = CatImage.labelWithKmeans(f, 11, 10);
		}
		
		img = CatImage.labelWithSpatialKmeans(f, 150, 10);
		
		if(Visioner.EXEC_THIS_BLOCK)
		{
			f = FileDataAccess.getDesktopFile("data-visioner101/blue-fish.txt");
			img.toText(f);
			Visioner.show(f);
		}
		
		f = FileDataAccess.getDesktopFile("data-visioner101/blue-fish.png");
		img.toPng(f);
		Visioner.show(f);
	}

}
