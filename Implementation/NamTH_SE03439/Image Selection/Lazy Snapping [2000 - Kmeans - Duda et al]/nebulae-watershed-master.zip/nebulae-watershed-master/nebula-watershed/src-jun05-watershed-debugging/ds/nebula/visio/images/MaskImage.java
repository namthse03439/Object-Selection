package ds.nebula.visio.images;

import java.awt.Color;
import java.awt.image.BufferedImage;

import ds.nebula.visio.func.ColorMapper;

public class MaskImage 
{
	private int Rx;
	private int Ry;
	private double[][] dataXY;

	public static MaskImage start(int Rx, int Ry) 
	{
		MaskImage res = new MaskImage();
		res.Rx = Rx;
		res.Ry = Ry;
		res.dataXY = new double[Rx][Ry];

		return res;
	}
	
	public int getRx()
	{
		return Rx;
	}
	
	public int getRy()
	{
		return Ry;
	}
	
	public double get(int x, int y)
	{
		return dataXY[x][y];
	}
	
	public void set(int x, int y, double v)
	{
		dataXY[x][y] = v;
	}
	
	public BufferedImage getBufferedImage(ColorMapper lf) 
	{
		BufferedImage res = new BufferedImage(Rx, Ry, BufferedImage.TYPE_INT_ARGB);
		
		double max = 0;
		for(int x=0; x<Rx; x++)
		for(int y=0; y<Ry; y++)
		{
			max = Math.max(max, dataXY[x][y]);
		}
		if(max == 0) max = 1;
		
		for(int x=0; x<Rx; x++)
		for(int y=0; y<Ry; y++)
		{
			double dxy = dataXY[x][y] / max;
			Color c = lf.invokeColorMapper(dxy);
			res.setRGB(x, y, c.getRGB());
		}
		
		return res;
	}


}
