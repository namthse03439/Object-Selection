package ds.nebula.forbak;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

public class ForbakDocument 
{
	private File imageFile;
	private List<ForbakPoint> points = new ArrayList<ForbakPoint>();
	private BufferedImage imageData;

	public static ForbakDocument startWithImage(File f) 
	throws Exception
	{
		ForbakDocument res = new ForbakDocument();
		res.imageFile = f;
		res.imageData = ImageIO.read(f);
		return res;
	}
	
	public File getFileForSaving()
	{
		return new File(imageFile.getAbsolutePath() + ".label");
	}
	
	public Dimension getSizeForRendering()
	{
		if(imageData == null) return new Dimension(1, 1);
		return new Dimension(imageData.getWidth(), imageData.getHeight());
	}
	
	public BufferedImage getImageForRendering()
	{
		if(imageData == null)
			return new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
		
		return new BufferedImage(
				imageData.getWidth(), imageData.getHeight(), imageData.getType());
	}
	
	public void addPixel(int x, int y, String col) 
	{
		ForbakPoint pk = new ForbakPoint();
		pk.x = x;
		pk.y = y;
		pk.color = col;
		points.add(pk);		
	}

	public void save(File f) 
	throws Exception
	{
		PrintWriter out = new PrintWriter(f);
		out.println("!FBS");
		
		out.println("@ref:" + f.getName());
		for(ForbakPoint pk: points)
		{
			out.println("@"+pk.color + ":" + pk.x + ":" + pk.y);
		}
		
		out.close();
	}

	public BufferedImage getImageAndAnchors() 
	{
		BufferedImage res = this.getImageForRendering();
		
		Graphics g = res.createGraphics();
		g.drawImage(this.imageData, 0, 0, null);
		
		int cx = 5, cy = 5;
		for(ForbakPoint pk: this.points)
		{
			if( pk.color.equals("F") ) g.setColor(Color.red);
			else g.setColor(Color.blue);
			
			int x = pk.x-cx/2;
			int y = pk.y-cy/2;
			g.drawOval(x, y, cx, cy);
		}
		g.dispose();
		
		return res;
	}

	public BufferedImage getImageData() 
	{
		return imageData;
	}

	public List<Point> getAnchorPoints(String c) 
	{
		List<Point> res = new ArrayList<Point>();
		
		for(ForbakPoint pk: points) 
		if(pk.color.equals(c)) 
		{
			for(int x=-3; x<3; x++)
			for(int y=-3; y<3; y++)
			res.add(new Point(pk.x+x, pk.y+y));
		}
		
		return res;
	}

	public void addPixels(int x1, int y1, int x2, int y2, String col) 
	{
		double a = (x2 - x1), b = (y2 - y1);
		int n = (int)Math.max(Math.abs(a), Math.abs(b));
		double len = Math.sqrt(a*a + b*b);
		a /= len;
		b /= len;
		
		for(int k=0; k<n; k++)
		{
			double x = x1 + a*k;
			double y = y1 + b*k;
			addPixel((int)x, (int)y, col);
		}
		
		
	}

}
