package org.naebulae.util;

public class Debug {

	public static void printFunc() {
		// TODO Auto-generated method stub
		
	}

}
