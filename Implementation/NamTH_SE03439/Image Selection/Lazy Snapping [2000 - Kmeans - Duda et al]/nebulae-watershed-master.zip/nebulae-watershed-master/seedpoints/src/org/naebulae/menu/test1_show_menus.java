package org.naebulae.menu;

import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Method;

public class test1_show_menus 
{
	public static void main(String[] args) 
	{
		List<Class<?>> items = fetchClasses(FileController.class);
		
		for(Class<?> x1: items) 
		{
			JsacMenu m1 = JsacMenu.start(x1);
			System.out.printf("-- name=%s shortcut=%s \n", 
					m1.getMenuName(), m1.getMenuShortcut() );
			
			for(Method x2: m1.reflectMethods())
			{
				JsacMenuItem m2 = JsacMenuItem.start(x2, m1);
				System.out.printf("-- -- name=%s shortcut=%s \n", 
						m2.getMenuName(), m2.getMenuShortcut() );
			} //for each item						
			
		} //for each menu
						
		return; 
	}

	private static List<Class<?>> fetchClasses(Class<?> cl)
	{
		List<Class<?>> res = new ArrayList<Class<?>>();
		res.add(cl);
		return res;
	}

}
