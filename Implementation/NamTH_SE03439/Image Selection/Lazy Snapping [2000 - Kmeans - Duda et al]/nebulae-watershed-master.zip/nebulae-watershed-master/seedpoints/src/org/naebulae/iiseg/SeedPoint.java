package org.naebulae.iiseg;

public class SeedPoint {

	public int centerX;
	public int centerY;
	public boolean background;

}
