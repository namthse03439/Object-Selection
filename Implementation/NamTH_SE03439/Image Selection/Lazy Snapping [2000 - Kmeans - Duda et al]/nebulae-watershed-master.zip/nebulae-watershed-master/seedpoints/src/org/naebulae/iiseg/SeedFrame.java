package org.naebulae.iiseg;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class SeedFrame extends JPanel 
implements KeyListener, MouseListener, MouseMotionListener 
{
   private SeedDocument data = new SeedDocument();
   
   public SeedFrame()
   {
	   this.addKeyListener(this);
	   this.addMouseListener(this);
	   this.addMouseMotionListener(this);
   }
   
   public void paintComponent(Graphics g) 
   {
	   BufferedImage img = data.getBackgroundImage();
	   if(img != null) g.drawImage(img, 0, 0, img.getWidth(), img.getHeight(), null);
	   
	   int cx = 4, cy = 4;
	   for(SeedPoint pk: data.getSeedPoints())
	   {
		   int xk = pk.centerX - cx/2;
		   int yk = pk.centerY - cy/2;
		   Color ck = (pk.background ? data.getBackgroundColor() : data.getForegroundColor());
		   g.setColor(ck);
		   g.drawRect(xk, yk, cx, cy);
	   }
	   
	   return;
   }
   
   
	   
	public static void show(File f1) 
	{
		SeedFrame f = new SeedFrame();
		f.setImage(f1);
		
		JFrame res = new JFrame();
		res.setSize(640, 480);
		res.setLocationRelativeTo(null);
		res.add(f);
		
		res.setVisible(true);
		
		f.setFocusable(true);
		f.requestFocus();
	}

	private void setImage(File f1) 
	{
		data.setBackgroundImage(f1);
	}
	


	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseMoved(MouseEvent arg0) 
	{
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseClicked(MouseEvent arg0) 
	{
		int x = arg0.getX();
		int y = arg0.getY();
		
		if( arg0.isAltDown() )
		{
			System.out.println("Removing point " + x + "; " + y);
			data.deletePointAt(x, y);
			this.repaint();
		}
		
		else 
		{
			System.out.println("Inserting point " + x + "; " + y);
			data.insertPointAt(x, y, arg0.isShiftDown());
			this.repaint();
		}
		
		return;
	}


	@Override
	public void mouseEntered(MouseEvent arg0) 
	{
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void keyPressed(KeyEvent arg0) 
	{
		if(arg0.isControlDown() && arg0.getKeyCode() == KeyEvent.VK_S) saveFile();
		else if(arg0.isControlDown() && arg0.getKeyCode() == KeyEvent.VK_O) openFile();
		
//		System.out.println("key-char: " + arg0.getKeyChar());
//		System.out.println("key-code: " + arg0.getKeyCode());
//		System.out.println("key-ctrl: " + arg0.isControlDown());
	}


	private File path = null;
	
	private void saveFile() 
	{
		if(path == null)
		{
			JFileChooser fileChooser = new JFileChooser();
			if (fileChooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return; 
			path = fileChooser.getSelectedFile();
		}
		
		if(path == null) return;
		
		this.data.saveAll(path);
		this.repaint();		
	}

	private void openFile() 
	{
		JFileChooser fileChooser = new JFileChooser();
		if (fileChooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return; 
		File file = fileChooser.getSelectedFile();
		
		SeedDocument d = SeedDocument.loadAll(file);
		if(d == null) return;
		
		this.data = d;
		this.repaint();
	}

	@Override
	public void keyReleased(KeyEvent arg0) 
	{
	}


	@Override
	public void keyTyped(KeyEvent arg0) 
	{
	}
	

}
