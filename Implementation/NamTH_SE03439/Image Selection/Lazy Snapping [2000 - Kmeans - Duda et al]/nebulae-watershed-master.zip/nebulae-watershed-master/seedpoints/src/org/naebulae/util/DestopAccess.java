package org.naebulae.util;

import java.awt.Desktop;
import java.io.File;

public class DestopAccess 
{
	public String pref = "";
	
	public static DestopAccess start()
	{
		DestopAccess res = new DestopAccess();
		res.pref = System.getProperty("user.home") + "/Desktop";
		
		return res;
	}

	public File getFile(String name) 
	{
		return new File(pref + "/" + name);
	}

	public void show(File f1) 
	{
		System.out.println("Showing " + f1.getAbsolutePath());
		try { Desktop.getDesktop().open(f1); }
		catch(Exception xp) { error(xp); }
	}

	protected void error(Object xp) 
	{
		if(xp instanceof Exception) 
			((Exception)xp).printStackTrace();
	}
	

}
