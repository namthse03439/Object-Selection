package org.naebulae.iiseg;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.naebulae.util.ErrorLogger;

public class SeedDocument 
{
	private BufferedImage backImage;
	private List<SeedPoint> points = new ArrayList<SeedPoint> ();
	
	public BufferedImage getBackgroundImage() 
	{
		return backImage;
	}
	

	public List<SeedPoint> getSeedPoints() 
	{
		return points;
	}

	public Color getBackgroundColor() 
	{
		return Color.black;
	}
	
	public Color getForegroundColor() 
	{
		return Color.red;
	}
	
	public void setBackgroundImage(File img)
	{
		try { backImage = ImageIO.read(img); }
		catch(Exception xp) { ErrorLogger.error(xp); }
	}

	public void setBackgroundImage(BufferedImage img)
	{
		backImage = img;
	}
	

	public void deletePointAt(int x, int y) 
	{
		
	}

	public void insertPointAt(int x, int y, boolean back) 
	{
		SeedPoint p = new SeedPoint();
		p.centerX = x;
		p.centerY = y;
		p.background = back;	
		
		this.points.add(p);
	}

	public static SeedDocument loadAll(File file) 
	{
		return null;
	}


	public void saveAll(File path) {
		// TODO Auto-generated method stub
		
	}
	
}
