package org.naebulae.util;

public class ErrorLogger {

	public static void error(Exception xp)
	{
		
	}

}
