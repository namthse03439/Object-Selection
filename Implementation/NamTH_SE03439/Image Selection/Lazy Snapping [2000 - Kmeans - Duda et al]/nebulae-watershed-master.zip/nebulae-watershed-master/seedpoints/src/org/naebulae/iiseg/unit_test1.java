package org.naebulae.iiseg;

import java.io.File;

import org.naebulae.util.DestopAccess;

public class unit_test1
{

	public static void main(String[] args) 
	{
		File f1 = DestopAccess.start().getFile("test1.jpg");
		//DestopAccess.start().show(f1);
		
		SeedFrame.show(f1);
	}
}

