package org.naebulae.menu;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

import org.naebulae.gunit.MenuBind;

public class JsacMenu 
{
	private Class<?> dataClass;

	public static JsacMenu start(Class<?> ik)
	{
		JsacMenu res = new JsacMenu();
		res.dataClass = ik;
		return res;
	}

	public Object getMenuName() 
	{
		MenuBind r = dataClass.getAnnotation(MenuBind.class);
		return (r==null ? "" : r.value() );
	}

	public Object getMenuShortcut() 
	{
		MenuBind r = dataClass.getAnnotation(MenuBind.class);
		return ( r==null ? "" : r.shortcut() );
	}

	public List<Method> reflectMethods() 
	{
		List<Method> res = new ArrayList<Method>();
		
		for(Method mk: dataClass.getMethods())
		if( Modifier.isPublic(mk.getModifiers())
				&& mk.getName().endsWith("Action")) res.add(mk);
		
		return res;
	}

}
