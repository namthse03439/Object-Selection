package org.naebulae.menu;

import org.naebulae.gunit.KeyBind;
import org.naebulae.gunit.MenuBind;
import org.naebulae.util.Debug;

@MenuBind(value="File", shortcut="F")
public class FileController
{

@MenuBind(value="New...", shortcut="N")
@KeyBind("Ctrl+N")
public void newAction() { Debug.printFunc(); }

@MenuBind(value="Open...",  shortcut="O")
@KeyBind("Ctrl+O")
public void openAction() { Debug.printFunc(); }

@MenuBind(value="Save ",  shortcut="S")
@KeyBind("Ctrl+S")
public void saveAction() { Debug.printFunc(); }

@MenuBind(value="Save as...",  shortcut="A")
@KeyBind("Ctrl+Shift+S")
public void saveAsAction() { Debug.printFunc(); }
}
