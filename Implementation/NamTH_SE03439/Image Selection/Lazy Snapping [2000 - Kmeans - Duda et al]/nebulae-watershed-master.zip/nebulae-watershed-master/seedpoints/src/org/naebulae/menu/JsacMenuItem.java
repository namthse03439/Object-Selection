package org.naebulae.menu;

import java.lang.reflect.Method;

import org.naebulae.gunit.MenuBind;

public class JsacMenuItem 
{
	private Method dataMethod;
	private JsacMenu dataParent;

	public static JsacMenuItem start(Method ik, JsacMenu pk)
	{
		JsacMenuItem res = new JsacMenuItem();
		res.dataMethod = ik;
		res.dataParent = pk;
		return res;
	}
	
	public Object getMenuName() 
	{
		MenuBind r = dataMethod.getAnnotation(MenuBind.class);
		return (r==null ? "" : r.value() );
	}
	
	public Object getMenuShortcut() 
	{
		MenuBind r = dataMethod.getAnnotation(MenuBind.class);
		return ( r==null ? "" : r.shortcut() );
	}

	public JsacMenu getParent()
	{
		return dataParent;
	}


}
